//: [Previous](@previous)
import UIkit
import Foundation

func removeConsecutiveDublicates (sentence: String) -> String{
    let sentenceArray = sentence.components (separateBy: [" "])
    var str = " "
    for world in sentenceArray{
        if str == " " || word != str.components(separatedBy: " ").last {
            str = str + " " + word
        }
    }
    return str
}


