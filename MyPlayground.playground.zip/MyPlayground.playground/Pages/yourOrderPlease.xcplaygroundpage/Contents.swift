//: [Previous](@previous)

import Foundation

func order (sentence: String)-> String {
    var digits = [Int]()
    var finalResult = " "
    let sentenceArray = sentence.components(separatedBy: [" "])
    for word in sentenceArray{
        var num = extractNum (str: word)
        digits.append(num)
    }
    for num in digits.sorted(){
        for word in sentenceArray{
            if word.contains(String(num)){
                finalResult = finalResult + " " + word

            }
        }
    }
    return finalResult
}

