//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)
func sort(string: String)-> String{
    var used = [Character]()
    for letter in string{
        if !used.contains(letter){
            used.append(letter)
        }
    }
    return String(used)
}
sort(string: "Hello")

